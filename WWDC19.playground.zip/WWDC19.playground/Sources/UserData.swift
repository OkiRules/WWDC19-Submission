import Foundation

struct UserData: Codable {
    
    let highScore: Int
    let hasUnlockedFreePlay: Bool
    
    init(highScore: Int, hasUnlockedFreePlay: Bool) {
        self.highScore = highScore
        self.hasUnlockedFreePlay = hasUnlockedFreePlay
    }
}

