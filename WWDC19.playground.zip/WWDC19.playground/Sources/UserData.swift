import Foundation

struct UserData: Codable {
    
    let highScore: Int
    let hasUnlockedFreePlay: Bool
    let usesParticles: Bool
    
    init(highScore: Int, hasUnlockedFreePlay: Bool, usesParticles: Bool) {
        self.highScore = highScore
        self.hasUnlockedFreePlay = hasUnlockedFreePlay
        self.usesParticles = usesParticles
    }
}

