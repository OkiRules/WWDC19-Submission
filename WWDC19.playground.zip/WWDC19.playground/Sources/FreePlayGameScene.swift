import PlaygroundSupport
import AVFoundation
import SpriteKit

public class FreePlayGameScene: SKScene, SKPhysicsContactDelegate, AVSpeechSynthesizerDelegate {
    
    // REMEMBER COMMENTS
    
    private var earthKillerNames = [String]()
    private var amountOfPollutionRemoved: Int = 0
    private var waitDuration: Double = 1.45
    private var speedOfEnemy: Double = 2.30
    private var originalWaitDuration: Double = 1.45
    private var originalSpeedOfEnemy: Double = 2.30
    private var highScore: Int = 0
    private var newScore: Int = 2
    private var didBeginFuctionRan: Bool = false
    private var planet: SKSpriteNode!
    private var scoreLabel: SKLabelNode!
    private var usesParticles: Bool = false
    private var smokeParticle: SKEmitterNode!
    private var fireParticle: SKEmitterNode!
    private var gasParticle: SKEmitterNode!
    private var explosionParticle: SKEmitterNode!
    private var fireworkParticle: SKEmitterNode!
    private let speechSynthesizer = AVSpeechSynthesizer()
    
    public override func didMove(to view: SKView) {
        
        physicsWorld.contactDelegate = self
        
        earthKillerNames = ["orange-car", "yellow-car", "blue-car", "pig", "chicken", "cow", "coal", "coal", "coal", "factory", "factory", "factory"]
        
        createPlanet()
        createScoreLabel()
        
        JSONExtentions.init().retrieveFromJsonFile { (userData, error) in
            
            if error != nil {
                
                print(error!)
            } else {
                
                guard
                    let usesParticles = userData?.usesParticles,
                    let waitDuration = userData?.waitDuration,
                    let speedOfEnemy = userData?.speedOfEnemy,
                    let highScore = userData?.highScore
                    else { return }
                
                self.usesParticles = usesParticles
                self.waitDuration = waitDuration
                self.speedOfEnemy = speedOfEnemy
                self.originalWaitDuration = waitDuration
                self.originalSpeedOfEnemy = speedOfEnemy
                self.highScore = highScore
            }
        }
        
        speechSynthesizer.delegate = self
        let speechUtterance = AVSpeechUtterance(string: "Welcome to Free Play mode, here you try to remove as much pollution as you can. Good luck!")
        speechUtterance.rate = 0.45
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        speechSynthesizer.speak(speechUtterance)
        
        self.removeAction(forKey: "music")
        let playMusic = SKAction.playSoundFileNamed("homeScreenMusic.mp3", waitForCompletion: true)
        self.run(SKAction.repeatForever(playMusic), withKey: "music")
        
        amountOfPollutionRemoved = 0
        
        // GET RID IF THESE
        view.showsFPS = true
        view.showsNodeCount = true
    }
    
    public func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        
        if utterance.speechString == "Welcome to Free Play mode, here you try to remove as much pollution as you can. Good luck!" {
            
            createEnemy()
            createEnemyLoop()
        }
    }
    
    func createEnemyLoop() {
        
        self.removeAction(forKey: "spawning")
        let waitAction = SKAction.wait(forDuration: TimeInterval(waitDuration))
        self.run(SKAction.repeatForever(SKAction.sequence([waitAction, SKAction.run {
            self.createEnemy()
            }])), withKey: "spawning")
        // CLEAN UP
    }
    
    func endGame() {
        
        var savingScore = highScore
        if amountOfPollutionRemoved > highScore {
            
            savingScore = amountOfPollutionRemoved
        }
        let userData = UserData(highScore: savingScore, hasUnlockedFreePlay: true, usesParticles: usesParticles, waitDuration: originalWaitDuration, speedOfEnemy: originalSpeedOfEnemy)
        JSONExtentions.init().saveToJsonFile(userData: userData) { (error) in
            
            if error != nil {
                
                print(error!)
            } else {
                
                view?.isPaused = false
                if let homeScreen = HomeScreen(fileNamed: "HomeScreen") {
                    
                    homeScreen.scaleMode = .aspectFill
                    let transition = SKTransition.fade(with: .black, duration: 2.75)
                    self.view?.presentScene(homeScreen, transition: transition)
                }
            }
        }
    }
    
    func createPlanet() {
        
        planet = childNode(withName: "planet") as? SKSpriteNode
        
        planet.texture = SKTexture(imageNamed: "earth")
        planet.size = CGSize(width: 80, height: 80)
        planet.physicsBody = SKPhysicsBody(texture: planet.texture!, size: CGSize(width: planet.size.width, height: planet.size.height))
        planet.physicsBody?.affectedByGravity = false
        planet.physicsBody?.isDynamic = true
        planet.physicsBody?.collisionBitMask = 0
        planet.physicsBody?.contactTestBitMask = 1
        planet.zPosition = 2
    }
    
    func createScoreLabel() {
        
        scoreLabel = childNode(withName: "scoreLabel") as? SKLabelNode
        
        scoreLabel.text = String(amountOfPollutionRemoved)
        scoreLabel.fontSize = 70
        scoreLabel.zPosition = 2
    }
    
    func createEnemy() {
        
        weak var weakSelf = self // DELETE THIS
        
        let random = arc4random() % 4 +  1
        var position = CGPoint()
        var moveTo = CGPoint()
        
        switch random {
            
        // Top
        case 1:
            
            let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxX)...Int(weakSelf!.frame.maxX))
            position = CGPoint(x: randomNumber, y: 250)
            
            moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
            
            break
            
        // Bottom
        case 2:
            
            let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxX)...Int(weakSelf!.frame.maxX))
            position = CGPoint(x: randomNumber, y: -250)
            
            moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
            
            break
            
        // Right
        case 3:
            
            let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxY)...Int(weakSelf!.frame.maxY))
            position = CGPoint(x: 370, y: randomNumber)
            
            moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
            
            break
            
        // Left
        case 4:
            
            let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxY)...Int(weakSelf!.frame.maxY))
            position = CGPoint(x: -370, y: randomNumber)
            
            moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
            
            break
            
        default:
            break
            
        }
        
        weakSelf!.spawnEnemyAtPosition(position: position, moveTo: moveTo)
    }
    
    func spawnEnemyAtPosition(position: CGPoint, moveTo: CGPoint) {
        
        if let carName = earthKillerNames.randomElement() {
            
            let enemy = SKSpriteNode(imageNamed: carName)
            
            if carName == "pig" || carName == "chicken" || carName == "cow" || carName == "factory" {
                
                if usesParticles {
                    
                    gasParticle = SKEmitterNode(fileNamed: "Gas")
                    gasParticle.position = CGPoint(x: 15, y: -15.0)
                    gasParticle.name = "gasParticle"
                    gasParticle.zPosition = 22.0
                    gasParticle.targetNode = self.scene
                    enemy.addChild(gasParticle)
                }
                enemy.size = CGSize(width: 80, height: 85)
            } else if carName == "yellow-car" || carName == "blue-car" || carName == "orange-car" {
                
                if usesParticles {
                    
                    smokeParticle = SKEmitterNode(fileNamed: "Smoke")
                    smokeParticle.position = CGPoint(x: 15, y: -15.0)
                    smokeParticle.name = "smokeParticle"
                    smokeParticle.zPosition = 22.0
                    smokeParticle.targetNode = self.scene
                    enemy.addChild(smokeParticle)
                }
                enemy.size = CGSize(width: 80, height: 80)
            } else if carName == "coal" {
                
                if usesParticles {
                    fireParticle = SKEmitterNode(fileNamed: "Fire")
                    fireParticle.position = CGPoint(x: 15, y: -15.0)
                    fireParticle.name = "someParticle"
                    fireParticle.zPosition = 22.0
                    fireParticle.targetNode = self.scene
                    enemy.addChild(fireParticle)
                }
                
                enemy.size = CGSize(width: 80, height: 80)
            }
            
            enemy.position = position
            enemy.physicsBody = SKPhysicsBody(texture: enemy.texture!, size: CGSize(width: enemy.size.width, height: enemy.size.height))
            enemy.physicsBody?.affectedByGravity = false
            enemy.physicsBody?.isDynamic = true
            enemy.physicsBody?.collisionBitMask = 1
            enemy.physicsBody?.contactTestBitMask = 1
            enemy.zPosition = 2
            enemy.name = "enemy"
            
            let rotateAction = SKAction.rotate(byAngle: 2.0 * CGFloat.pi, duration: 10.0)
            let move = SKAction.move(to: moveTo, duration: speedOfEnemy)
            enemy.run(move, withKey: "moveAction")
            enemy.run(rotateAction, withKey: "rotateAction")
            self.addChild(enemy)
        }
    }
    
    public func didBegin(_ contact: SKPhysicsContact) {
        
        let firstBody = contact.bodyA.node as! SKSpriteNode
        let secondBody = contact.bodyB.node as! SKSpriteNode
        if firstBody.name == "planet" && secondBody.name == "enemy" {
            
            if didBeginFuctionRan == false {
                
                didBeginFuctionRan = true
                
                for child in children {
                    
                    if child.name == "enemy" || child.name == "explosionParticle" {
                        
                        child.removeFromParent()
                    }
                }
                
                scoreLabel.isHidden = true
                view?.isPaused = true
                
                endGame()
            }
        }
    }
    
    func randomBetweenNumbers(firstNum: CGFloat, secondNum: CGFloat) -> CGFloat {
        
        return CGFloat(arc4random()) / CGFloat(UINT32_MAX) * abs(firstNum - secondNum) + min(firstNum, secondNum)
    }
    
    func randomPointBetween(start: CGPoint, end: CGPoint) -> CGPoint {
        
        return CGPoint(x: randomBetweenNumbers(firstNum: start.x, secondNum: end.x), y: randomBetweenNumbers(firstNum: start.y, secondNum: end.y))
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let touch = touches.first else { return }
        let positionInScene = touch.location(in: self)
        let touchedNode = self.atPoint(positionInScene)
        
        if let name = touchedNode.name {
            if name == "enemy" {
                
                amountOfPollutionRemoved += 1
                scoreLabel.text = String(amountOfPollutionRemoved)
                touchedNode.removeAllActions()
                
                explosionParticle = SKEmitterNode(fileNamed: "ExplosionParticle")
                explosionParticle.position = touchedNode.position
                explosionParticle.name = "explosionParticle"
                explosionParticle.zPosition = 22.0
                explosionParticle.targetNode = self.scene
                touchedNode.removeFromParent()
                
                let addEmitterAction = SKAction.run({
                    self.explosionParticle.name = "explosionParticle"
                    self.addChild(self.explosionParticle)
                })
                let playExplosionSound = SKAction.playSoundFileNamed("explosion.mp3", waitForCompletion: false)
                let wait = SKAction.wait(forDuration: TimeInterval(0.5))
                let remove = SKAction.run({
                    self.explosionParticle.removeFromParent()
                })
                
                let sequence = SKAction.sequence([addEmitterAction, playExplosionSound, wait, remove])
                
                self.run(sequence)
            } else if name == "backButton" {
                
                for child in children {
                    
                    if child.name == "enemy" {
                        
                        child.removeFromParent()
                    }
                }
                
                speechSynthesizer.stopSpeaking(at: .immediate)
                
                // INTERGRATE INTO ENDGAME FUNCTION - STORE IN VARIBLE - UNLOCKED - TO NOT GET MESSED UP IF ANOTHER GAME IS PLAYED.
                var savingScore = highScore
                if amountOfPollutionRemoved > highScore {
                    
                    savingScore = amountOfPollutionRemoved
                }
                let userData = UserData(highScore: savingScore, hasUnlockedFreePlay: true, usesParticles: usesParticles, waitDuration: originalWaitDuration, speedOfEnemy: originalSpeedOfEnemy)
                JSONExtentions.init().saveToJsonFile(userData: userData) { (error) in
                    
                    if error != nil {
                        
                        print(error!)
                    } else {
                        if let homeScreen = HomeScreen(fileNamed: "HomeScreen") {
                            
                            homeScreen.scaleMode = .aspectFill
                            let transition = SKTransition.fade(with: .black, duration: 2.75)
                            self.view?.presentScene(homeScreen, transition: transition)
                        }
                    }
                }
            }
        }
    }
    
    public override func update(_ currentTime: TimeInterval) {
        
        if newScore == amountOfPollutionRemoved {
            
            newScore += 2
            waitDuration -= 0.13
            speedOfEnemy -= 0.13
            createEnemyLoop()
        }
    }
}

