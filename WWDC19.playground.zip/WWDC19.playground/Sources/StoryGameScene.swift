import PlaygroundSupport
import AVFoundation
import SpriteKit

public class StoryGameScene: SKScene, SKPhysicsContactDelegate, AVSpeechSynthesizerDelegate {
    
    // REMEMBER COMMENTS
    
    private var earthKillerNames = [String]()
    private var amountOfPollutionRemoved: Int = 0
    private var waitDuration: Double = 1.45
    private var speedOfEnemy: Double = 2.30
    private var scoreAim: Int = 5
    private var didBeginFuctionRan: Bool = false
    private var planet: SKSpriteNode!
    private var scoreLabel: SKLabelNode!
    private var usesParticles: Bool = false
    private var smokeParticle: SKEmitterNode!
    private var fireParticle: SKEmitterNode!
    private var gasParticle: SKEmitterNode!
    private var explosionParticle: SKEmitterNode!
    private var fireworkParticle: SKEmitterNode!
    private let speechSynthesizer = AVSpeechSynthesizer()
    
    public override func didMove(to view: SKView) {
        
        physicsWorld.contactDelegate = self
        
        earthKillerNames = ["orange-car", "yellow-car", "blue-car"]
        
        createPlanet()
        createScoreLabel()
        
        JSONExtentions.init().retrieveFromJsonFile { (error, userData) in
            
            if error != nil {
                
                print(error!)
            } else {
                
                if let bollean = userData?.usesParticles {
                    
                    usesParticles = bollean as! Bool
                }
            }
        }
        
        speechSynthesizer.delegate = self
        let speechUtterance = AVSpeechUtterance(string: "Welcome to the Earth, this is where all the petty humans live, they create so much pollution the planet is heating up! I think we should help them, one of the main causes of Global Warming is cars, cars create pollution so lets try to get rid of it. Hit 5 cars to help reduce pollution!")
        speechUtterance.rate = 0.45
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        speechSynthesizer.speak(speechUtterance)
        
        self.removeAction(forKey: "music")
        let playMusic = SKAction.playSoundFileNamed("homeScreenMusic.mp3", waitForCompletion: true)
        self.run(SKAction.repeatForever(playMusic), withKey: "music")
        
        waitDuration = 1.45
        speedOfEnemy = 2.30
        scoreAim = 5
        
        // GET RID IF THESE
        view.showsFPS = true
        view.showsNodeCount = true
    }
    
    public func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        
        if utterance.speechString == "Oh no! Pollution is starting to take over Earth, quickly get rid of the pollution to save the planet!" {
            
            didBeginFuctionRan = false
            
            scoreLabel.isHidden = false
            view?.isPaused = false
            createEnemies()
            spawnFirstEnemy()
            
            for child in children {
                
                if child.name == "enemy" || child.name == "explosionParticle" {
                    
                    child.removeFromParent()
                }
            }
            
        } else if utterance.speechString == "Well done! You have saved Earth and all of it's plants, animals and people, so now we can get on to create new experiences for developers and the rest of the world! You can now access free play mode to try clear as much pollution as you can. Thanks for playing my game, I hope to meet you at WWDC19!" {
            
            endGame()
        } else {
            
            for child in children {
                
                if child.name == "enemy" || child.name == "explosionParticle" {
                    
                    child.removeFromParent()
                }
            }
            
            scoreLabel.isHidden = false
            createEnemies()
            spawnFirstEnemy()
        }
    }
    
    func endGame() {
        
        let userData = UserData(highScore: 13, hasUnlockedFreePlay: true, usesParticles: usesParticles)
        JSONExtentions.init().saveToJsonFile(userData: userData) { (error) in
            
            if error != nil {
                
                print(error!)
            } else {
                if let homeScreen = HomeScreen(fileNamed: "HomeScreen") {
                    
                    homeScreen.scaleMode = .aspectFill
                    let transition = SKTransition.fade(with: .black, duration: 2.75)
                    self.view?.presentScene(homeScreen, transition: transition)
                }
            }
        }
    }
    
    func createPlanet() {
        
        planet = childNode(withName: "planet") as? SKSpriteNode
        
        planet.texture = SKTexture(imageNamed: "earth")
        planet.size = CGSize(width: 80, height: 80)
        planet.physicsBody = SKPhysicsBody(texture: planet.texture!, size: CGSize(width: planet.size.width, height: planet.size.height))
        planet.physicsBody?.affectedByGravity = false
        planet.physicsBody?.isDynamic = true
        planet.physicsBody?.collisionBitMask = 0
        planet.physicsBody?.contactTestBitMask = 1
        planet.zPosition = 2
    }
    
    func createScoreLabel() {
        
        scoreLabel = childNode(withName: "scoreLabel") as? SKLabelNode
        
        scoreLabel.text = String(amountOfPollutionRemoved)
        scoreLabel.fontSize = 70
        scoreLabel.zPosition = 2
    }
    
    func spawnFirstEnemy() {
        
        weak var weakSelf = self
        let spawn = SKAction.run({
            
            let random = arc4random() % 4 +  1
            var position = CGPoint()
            var moveTo = CGPoint()
            
            switch random {
                
            // Top
            case 1:
                
                let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxX)...Int(weakSelf!.frame.maxX))
                position = CGPoint(x: randomNumber, y: 250)
                
                moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
                
                break
                
            // Bottom
            case 2:
                
                let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxX)...Int(weakSelf!.frame.maxX))
                position = CGPoint(x: randomNumber, y: -250)
                
                moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
                
                break
                
            // Right
            case 3:
                
                let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxY)...Int(weakSelf!.frame.maxY))
                position = CGPoint(x: 370, y: randomNumber)
                
                moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
                
                break
                
            // Left
            case 4:
                
                let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxY)...Int(weakSelf!.frame.maxY))
                position = CGPoint(x: -370, y: randomNumber)
                
                moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
                
                break
                
            default:
                break
                
            }
            
            weakSelf!.spawnEnemyAtPosition(position: position, moveTo: moveTo)
        })
        
        self.run(spawn)
    }
    
    func createEnemies() {
        
        let wait = SKAction.wait(forDuration: TimeInterval(waitDuration))
        weak var weakSelf = self
        let spawn = SKAction.run({
            
            let random = arc4random() % 4 +  1
            var position = CGPoint()
            var moveTo = CGPoint()
            
            switch random {
                
            // Top
            case 1:
                
                let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxX)...Int(weakSelf!.frame.maxX))
                position = CGPoint(x: randomNumber, y: 250)
                
                moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
                
                break
                
            // Bottom
            case 2:
                
                let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxX)...Int(weakSelf!.frame.maxX))
                position = CGPoint(x: randomNumber, y: -250)
                
                moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
                
                break
                
            // Right
            case 3:
                
                let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxY)...Int(weakSelf!.frame.maxY))
                position = CGPoint(x: 370, y: randomNumber)
                
                moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
                
                break
                
            // Left
            case 4:
                
                let randomNumber = Int.random(in: Int(-weakSelf!.frame.maxY)...Int(weakSelf!.frame.maxY))
                position = CGPoint(x: -370, y: randomNumber)
                
                moveTo = CGPoint(x: self.planet.position.x, y: self.planet.position.y)
                
                break
                
            default:
                break
                
            }
            
            weakSelf!.spawnEnemyAtPosition(position: position, moveTo: moveTo)
        })
        
        let spawning = SKAction.sequence([wait, spawn])
        self.run(SKAction.repeatForever(spawning), withKey: "spawning")
    }
    
    func spawnEnemyAtPosition(position: CGPoint, moveTo: CGPoint) {
        
        if let carName = earthKillerNames.randomElement() {
            
            let enemy = SKSpriteNode(imageNamed: carName)
            
            if carName == "pig" || carName == "chicken" || carName == "cow" || carName == "factory" {
                
                if usesParticles {
                    
                    gasParticle = SKEmitterNode(fileNamed: "Gas")
                    gasParticle.position = CGPoint(x: 15, y: -15.0)
                    gasParticle.name = "gasParticle"
                    gasParticle.zPosition = 22.0
                    gasParticle.targetNode = self.scene
                    enemy.addChild(gasParticle)
                }
                enemy.size = CGSize(width: 80, height: 85)
            } else if carName == "yellow-car" || carName == "blue-car" || carName == "orange-car" {
                
                if usesParticles {
                    
                    smokeParticle = SKEmitterNode(fileNamed: "Smoke")
                    smokeParticle.position = CGPoint(x: 15, y: -15.0)
                    smokeParticle.name = "smokeParticle"
                    smokeParticle.zPosition = 22.0
                    smokeParticle.targetNode = self.scene
                    enemy.addChild(smokeParticle)
                }
                enemy.size = CGSize(width: 80, height: 80)
            } else if carName == "coal" {
                
                if usesParticles {
                    fireParticle = SKEmitterNode(fileNamed: "Fire")
                    fireParticle.position = CGPoint(x: 15, y: -15.0)
                    fireParticle.name = "someParticle"
                    fireParticle.zPosition = 22.0
                    fireParticle.targetNode = self.scene
                    enemy.addChild(fireParticle)
                }
                
                enemy.size = CGSize(width: 80, height: 80)
            }
            
            enemy.position = position
            enemy.physicsBody = SKPhysicsBody(texture: enemy.texture!, size: CGSize(width: enemy.size.width, height: enemy.size.height))
            enemy.physicsBody?.affectedByGravity = false
            enemy.physicsBody?.isDynamic = true
            enemy.physicsBody?.collisionBitMask = 1
            enemy.physicsBody?.contactTestBitMask = 1
            enemy.zPosition = 2
            enemy.name = "enemy"
            
            let rotateAction = SKAction.rotate(byAngle: 2.0 * CGFloat.pi, duration: 10.0)
            let move = SKAction.move(to: moveTo, duration: speedOfEnemy)
            enemy.run(move, withKey: "moveAction")
            enemy.run(rotateAction, withKey: "rotateAction")
            self.addChild(enemy)
        }
    }
    
    func rotate(nodePosition: CGPoint, targetPosition: CGPoint) -> CGFloat {
        
        let deltaX = Float(targetPosition.x - nodePosition.x)
        let deltaY = Float(targetPosition.y - nodePosition.y)
        let pi = CGFloat.pi
        let angle = CGFloat(atan2f(deltaY, deltaX))
        var newAngle = angle
        
        if angle < (-pi / 2) {
            newAngle += 2 * pi
        }
        return newAngle - pi / 2
    }
    
    public func didBegin(_ contact: SKPhysicsContact) {
        
        let firstBody = contact.bodyA.node as! SKSpriteNode
        let secondBody = contact.bodyB.node as! SKSpriteNode
        if firstBody.name == "planet" && secondBody.name == "enemy" {
            
            if didBeginFuctionRan == false {
                
                didBeginFuctionRan = true
                
                for child in children {
                    
                    if child.name == "enemy" || child.name == "explosionParticle" {
                        
                        child.removeFromParent()
                    }
                }
                
                amountOfPollutionRemoved = 0
                scoreLabel.text = String(amountOfPollutionRemoved)
                scoreLabel.isHidden = true
                view?.isPaused = true
                
                let speechUtterance = AVSpeechUtterance(string: "Oh no! Pollution is starting to take over Earth, quickly get rid of the pollution to save the planet!")
                speechUtterance.rate = 0.45
                speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
                speechSynthesizer.speak(speechUtterance)
            }
        }
    }
    
    func randomBetweenNumbers(firstNum: CGFloat, secondNum: CGFloat) -> CGFloat {
        
        return CGFloat(arc4random()) / CGFloat(UINT32_MAX) * abs(firstNum - secondNum) + min(firstNum, secondNum)
    }
    
    func randomPointBetween(start: CGPoint, end: CGPoint) -> CGPoint {
        
        return CGPoint(x: randomBetweenNumbers(firstNum: start.x, secondNum: end.x), y: randomBetweenNumbers(firstNum: start.y, secondNum: end.y))
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let touch = touches.first else { return }
        let positionInScene = touch.location(in: self)
        let touchedNode = self.atPoint(positionInScene)
        
        if let name = touchedNode.name {
            if name == "enemy" {
                
                amountOfPollutionRemoved += 1
                scoreLabel.text = String(amountOfPollutionRemoved)
                touchedNode.removeAllActions()
                
                explosionParticle = SKEmitterNode(fileNamed: "ExplosionParticle")
                explosionParticle.position = touchedNode.position
                explosionParticle.name = "explosionParticle"
                explosionParticle.zPosition = 22.0
                explosionParticle.targetNode = self.scene
                touchedNode.removeFromParent()
                
                let addEmitterAction = SKAction.run({
                    self.explosionParticle.name = "explosionParticle"
                    self.addChild(self.explosionParticle)
                })
                let playExplosionSound = SKAction.playSoundFileNamed("explosion.mp3", waitForCompletion: false)
                let wait = SKAction.wait(forDuration: TimeInterval(0.5))
                let remove = SKAction.run({
                    self.explosionParticle.removeFromParent()
                })
                
                let sequence = SKAction.sequence([addEmitterAction, playExplosionSound, wait, remove])
                
                self.run(sequence)
            }
        }
    }
    
    public override func update(_ currentTime: TimeInterval) {
        
        if amountOfPollutionRemoved == scoreAim {
            
            self.removeAction(forKey: "spawning")
            if scoreAim == 5 {
                
                scoreLabel.isHidden = true
                amountOfPollutionRemoved = 0
                scoreLabel.text = String(amountOfPollutionRemoved)
                
                for child in children {
                    
                    if child.name == "enemy" {
                        
                        child.removeFromParent()
                    }
                }
                
                earthKillerNames.append("pig")
                earthKillerNames.append("chicken")
                earthKillerNames.append("cow")
                
                waitDuration = 1.25
                speedOfEnemy = 2.15
                scoreAim = 7
                
                let speechUtterance = AVSpeechUtterance(string: "Well done you just helped Earth by cleaning out some of the pollution. It feels good dosent it? I think we can help them a bit more though, lets try to also get rid of some animals that produce toxic gases! Hit 7 cars or animals to reduce pollution!")
                speechUtterance.rate = 0.45
                speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
                
                let wait = SKAction.wait(forDuration: TimeInterval(0.7))
                let speak = SKAction.run {
                    self.speechSynthesizer.speak(speechUtterance)
                }
                let sequence = SKAction.sequence([wait, speak])
                
                self.run(sequence)
            } else if scoreAim == 7 {
                
                scoreLabel.isHidden = true
                amountOfPollutionRemoved = 0
                scoreLabel.text = String(amountOfPollutionRemoved)
                
                for child in children {
                    
                    if child.name == "enemy" {
                        
                        child.removeFromParent()
                    }
                }
                
                earthKillerNames.append("coal")
                earthKillerNames.append("coal")
                earthKillerNames.append("coal")
                
                waitDuration = 1.15
                speedOfEnemy = 2.05
                scoreAim = 10
                
                let speechUtterance = AVSpeechUtterance(string: "Amazing! Earth is becoming cleaner by the minute but these rotten humans do such bad things for the environment! Let's keep cleaning up their mess to make Earth a better place for all! Hit 10 cars, animals or pieces of coal to almost make Earth as clean as can be!")
                speechUtterance.rate = 0.45
                speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
                
                let wait = SKAction.wait(forDuration: TimeInterval(0.7))
                let speak = SKAction.run {
                    self.speechSynthesizer.speak(speechUtterance)
                }
                let sequence = SKAction.sequence([wait, speak])
                
                self.run(sequence)
            } else if scoreAim == 10 {
                
                scoreLabel.isHidden = true
                amountOfPollutionRemoved = 0
                scoreLabel.text = String(amountOfPollutionRemoved)
                
                for child in children {
                    
                    if child.name == "enemy" {
                        
                        child.removeFromParent()
                    }
                }
                
                earthKillerNames.append("factory")
                earthKillerNames.append("factory")
                earthKillerNames.append("factory")
                
                waitDuration = 1.00
                speedOfEnemy = 1.80
                scoreAim = 13
                
                let speechUtterance = AVSpeechUtterance(string: "We're so close, theres only one more thing to clear. Hit 13 factories, cars, animals or pieces of coal to make Earth as clean as can be!")
                speechUtterance.rate = 0.45
                speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
                
                let wait = SKAction.wait(forDuration: TimeInterval(0.7))
                let speak = SKAction.run {
                    self.speechSynthesizer.speak(speechUtterance)
                }
                let sequence = SKAction.sequence([wait, speak])
                
                self.run(sequence)
            } else if scoreAim == 13 {
                
                scoreLabel.isHidden = true
                amountOfPollutionRemoved = 0
                
                for child in children {
                    
                    if child.name == "enemy" {
                        
                        child.removeFromParent()
                    }
                }
                
                let speechUtterance = AVSpeechUtterance(string: "Well done! You have saved Earth and all of it's plants, animals and people, so now we can get on to create new experiences for developers and the rest of the world! Thanks for playing my game, I hope to meet you at WWDC19!")
                speechUtterance.rate = 0.45
                speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
                
                let wait = SKAction.wait(forDuration: TimeInterval(0.7))
                let speak = SKAction.run {
                    self.speechSynthesizer.speak(speechUtterance)
                }
                let sequence = SKAction.sequence([wait, speak])
                
                self.run(sequence)
            }
        }
    }
}

