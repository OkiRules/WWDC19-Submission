import SpriteKit
import PlaygroundSupport
import Foundation
import AVFoundation

public class HomeScreen: SKScene {
    
    // COMMENTS
    private var freePlayGameLabel: SKLabelNode!
    private var highScoreLabel: SKLabelNode!
    var hasUnlockedFreePlay = false
    public var waitDuration = 1.45
    public var speedOfEnemy = 2.30
    private let speechSynthesizer = AVSpeechSynthesizer()
    public var usesParticles = false
    
    public override func didMove(to view: SKView) {
        
        self.removeAction(forKey: "music")
        let playMusic = SKAction.playSoundFileNamed("homeScreenMusic.mp3", waitForCompletion: true)
        self.run(SKAction.repeatForever(playMusic), withKey: "music")
        
        freePlayGameLabel = childNode(withName: "freePlayGameLabel") as? SKLabelNode
        highScoreLabel = childNode(withName: "highScoreLabel") as? SKLabelNode
        
        // USE JSONEXTENTIONS()...
        
        let fontURL = Bundle.main.url(forResource: "Herculanum", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        JSONExtentions.init().retrieveFromJsonFile { (userData, error) in
            
            if error != nil {
                
                if error?.localizedDescription == "The file “UserData.json” couldn’t be opened because there is no such file." {
                    
                    let userData = UserData(
                        highScore: 0,
                        hasUnlockedFreePlay: false,
                        usesParticles: usesParticles,
                        waitDuration: waitDuration,
                        speedOfEnemy: speedOfEnemy
                    )
                    JSONExtentions.init().saveToJsonFile(userData: userData) { (error) in
                        
                        if error != nil {
                            
                            print(error!)
                        } else {
                            
                            // CHANGE TEXT INTO EXTENTIONS WITH VARIBLE "highScoreText"
                            self.hasUnlockedFreePlay = userData.hasUnlockedFreePlay
                            if userData.highScore != 0 {
                                
                                highScoreLabel.text = "High Score: \(userData.highScore)"
                            }
                        }
                    }
                } else {
                    
                    print(error!)
                }
            } else {
                
                guard
                    let highScore = userData?.highScore,
                    let hasUnlockedFreePlay = userData?.hasUnlockedFreePlay,
                    let waitDuration = userData?.waitDuration,
                    let speedOfEnemy = userData?.speedOfEnemy
                    else { return }
                let userData = UserData(
                    highScore: highScore,
                    hasUnlockedFreePlay: hasUnlockedFreePlay,
                    usesParticles: usesParticles,
                    waitDuration: waitDuration,
                    speedOfEnemy: speedOfEnemy
                )
                JSONExtentions.init().saveToJsonFile(userData: userData) { (error) in
                    
                    if error != nil {
                        
                        print(error!)
                    } else {
                        
                        self.hasUnlockedFreePlay = userData.hasUnlockedFreePlay
                    }
                }
            }
        }
        
        if !hasUnlockedFreePlay {
            
            freePlayGameLabel.fontColor = .red
        } else {
            
            freePlayGameLabel.fontColor = .white
        }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let touch = touches.first else { return }
        let locationTouched = touch.location(in: self)
        let nodesAtLocation = nodes(at: locationTouched)
        // DO NOT USE TO SEPEERATE FILES
        if nodesAtLocation.isEmpty == false {
            
            if nodesAtLocation[0].name == "startGameLabel" {
                if let storyGameScene = StoryGameScene(fileNamed: "StoryGameScene") {
                    
                    storyGameScene.scaleMode = .aspectFill
                    let transition = SKTransition.fade(with: .black, duration: 2.75)
                    self.view?.presentScene(storyGameScene, transition: transition)
                }
            } else if nodesAtLocation[0].name == "aboutGameLabel" {
                if let aboutScreen = AboutScreen(fileNamed: "AboutScreen") {
                    
                    aboutScreen.scaleMode = .aspectFill
                    let transition = SKTransition.fade(with: .black, duration: 2.75)
                    self.view?.presentScene(aboutScreen, transition: transition)
                }
            } else if nodesAtLocation[0].name == "freePlayGameLabel" {
                if let freePlayGameScene = FreePlayGameScene(fileNamed: "FreePlayGameScene") {
                    
                    if !hasUnlockedFreePlay {
                        
                        let speechUtterance = AVSpeechUtterance(string: "You don't have free play mode unlocked yet, beat story mode to unlock it!")
                        speechUtterance.rate = 0.45
                        speechUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
                        speechSynthesizer.speak(speechUtterance)
                    } else {
                        
                        freePlayGameScene.scaleMode = .aspectFill
                        let transition = SKTransition.fade(with: .black, duration: 2.75)
                        self.view?.presentScene(freePlayGameScene, transition: transition)
                    }
                }
            }
        }
    }
}
