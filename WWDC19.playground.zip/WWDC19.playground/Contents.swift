import PlaygroundSupport
import SpriteKit

// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
if let homeScreen = HomeScreen(fileNamed: "HomeScreen") {
    // Set the scale mode to scale to fit the window
    homeScreen.scaleMode = .aspectFill
    
    // Present the scene
    sceneView.presentScene(homeScreen)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
