import PlaygroundSupport
import SpriteKit

// Would you like to use particles? If you choose yes this may result in a laggy game.
let usesParticles = true

// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 640, height: 480))
if let homeScreen = HomeScreen(fileNamed: "HomeScreen") {
    // Set the scale mode to scale to fit the window
    homeScreen.scaleMode = .aspectFill
    homeScreen.usesParticles = usesParticles
    
    // Present the scene
    sceneView.presentScene(homeScreen)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
